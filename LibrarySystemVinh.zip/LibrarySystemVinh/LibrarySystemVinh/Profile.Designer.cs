﻿namespace LibrarySystemVinh
{
    partial class Profile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            btnCancel = new Button();
            btnUpdate = new Button();
            panel2 = new Panel();
            btnExit = new Button();
            label7 = new Label();
            dgvProfile = new DataGridView();
            label4 = new Label();
            txtUname = new TextBox();
            txtUid = new TextBox();
            label1 = new Label();
            label2 = new Label();
            txtEmail = new TextBox();
            txtPass = new TextBox();
            label3 = new Label();
            label5 = new Label();
            txtRole = new TextBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvProfile).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.CornflowerBlue;
            panel1.Controls.Add(btnCancel);
            panel1.Controls.Add(btnUpdate);
            panel1.Controls.Add(panel2);
            panel1.Controls.Add(btnExit);
            panel1.Controls.Add(label7);
            panel1.Location = new Point(0, -1);
            panel1.Name = "panel1";
            panel1.Size = new Size(218, 675);
            panel1.TabIndex = 81;
            // 
            // btnCancel
            // 
            btnCancel.BackColor = Color.WhiteSmoke;
            btnCancel.Font = new Font("Segoe UI", 11F);
            btnCancel.ForeColor = SystemColors.ActiveCaptionText;
            btnCancel.Location = new Point(23, 252);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(169, 45);
            btnCancel.TabIndex = 78;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = false;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.BackColor = Color.WhiteSmoke;
            btnUpdate.Font = new Font("Segoe UI", 11F);
            btnUpdate.ForeColor = SystemColors.ActiveCaptionText;
            btnUpdate.Location = new Point(23, 153);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(169, 45);
            btnUpdate.TabIndex = 77;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = false;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Black;
            panel2.Location = new Point(0, 80);
            panel2.Name = "panel2";
            panel2.Size = new Size(218, 1);
            panel2.TabIndex = 76;
            // 
            // btnExit
            // 
            btnExit.BackColor = Color.Tomato;
            btnExit.Font = new Font("Segoe UI", 11F);
            btnExit.ForeColor = SystemColors.ButtonHighlight;
            btnExit.Location = new Point(23, 355);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(169, 45);
            btnExit.TabIndex = 75;
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = false;
            btnExit.Click += btnExit_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label7.ForeColor = SystemColors.Control;
            label7.Location = new Point(49, 25);
            label7.Name = "label7";
            label7.Size = new Size(123, 28);
            label7.TabIndex = 74;
            label7.Text = "User Profile";
            // 
            // dgvProfile
            // 
            dgvProfile.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvProfile.BackgroundColor = Color.WhiteSmoke;
            dgvProfile.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvProfile.Location = new Point(224, 298);
            dgvProfile.Name = "dgvProfile";
            dgvProfile.RowHeadersWidth = 51;
            dgvProfile.Size = new Size(1034, 296);
            dgvProfile.TabIndex = 82;
            dgvProfile.CellContentClick += dgvProfile_CellContentClick;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 11F);
            label4.Location = new Point(273, 220);
            label4.Name = "label4";
            label4.Size = new Size(62, 25);
            label4.TabIndex = 86;
            label4.Text = "Email:";
            // 
            // txtUname
            // 
            txtUname.Font = new Font("Segoe UI", 10F);
            txtUname.Location = new Point(398, 151);
            txtUname.Name = "txtUname";
            txtUname.Size = new Size(249, 30);
            txtUname.TabIndex = 85;
            // 
            // txtUid
            // 
            txtUid.Font = new Font("Segoe UI", 10F);
            txtUid.Location = new Point(398, 79);
            txtUid.Name = "txtUid";
            txtUid.Size = new Size(132, 30);
            txtUid.TabIndex = 84;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11F);
            label1.Location = new Point(273, 84);
            label1.Name = "label1";
            label1.Size = new Size(95, 25);
            label1.TabIndex = 83;
            label1.Text = "ID (Fixed):";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 11F);
            label2.Location = new Point(273, 151);
            label2.Name = "label2";
            label2.Size = new Size(106, 25);
            label2.TabIndex = 87;
            label2.Text = "User name:";
            // 
            // txtEmail
            // 
            txtEmail.Font = new Font("Segoe UI", 10F);
            txtEmail.Location = new Point(398, 220);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(249, 30);
            txtEmail.TabIndex = 88;
            // 
            // txtPass
            // 
            txtPass.Font = new Font("Segoe UI", 10F);
            txtPass.Location = new Point(860, 79);
            txtPass.Name = "txtPass";
            txtPass.Size = new Size(249, 30);
            txtPass.TabIndex = 89;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11F);
            label3.Location = new Point(726, 80);
            label3.Name = "label3";
            label3.Size = new Size(95, 25);
            label3.TabIndex = 90;
            label3.Text = "Password:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 11F);
            label5.Location = new Point(726, 151);
            label5.Name = "label5";
            label5.Size = new Size(115, 25);
            label5.TabIndex = 92;
            label5.Text = "Role (fixed): ";
            // 
            // txtRole
            // 
            txtRole.Font = new Font("Segoe UI", 10F);
            txtRole.Location = new Point(860, 150);
            txtRole.Name = "txtRole";
            txtRole.Size = new Size(133, 30);
            txtRole.TabIndex = 91;
            // 
            // Profile
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1262, 673);
            Controls.Add(label5);
            Controls.Add(txtRole);
            Controls.Add(label3);
            Controls.Add(txtPass);
            Controls.Add(txtEmail);
            Controls.Add(label2);
            Controls.Add(label4);
            Controls.Add(txtUname);
            Controls.Add(txtUid);
            Controls.Add(label1);
            Controls.Add(dgvProfile);
            Controls.Add(panel1);
            Name = "Profile";
            Text = "Profile";
            Load += Profile_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvProfile).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Button btnExit;
        private Label label7;
        private DataGridView dgvProfile;
        private Button btnCancel;
        private Button btnUpdate;
        private Label label4;
        private TextBox txtUname;
        private TextBox txtUid;
        private Label label1;
        private Label label2;
        private TextBox txtEmail;
        private TextBox txtPass;
        private Label label3;
        private Label label5;
        private TextBox txtRole;
    }
}