﻿namespace LibrarySystemVinh
{
    partial class Geres
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvGenres = new DataGridView();
            label1 = new Label();
            txtGid = new TextBox();
            txtGname = new TextBox();
            label2 = new Label();
            txtGdes = new RichTextBox();
            label3 = new Label();
            btnAdd = new Button();
            btnUpdate = new Button();
            btnDelete = new Button();
            btnCancel = new Button();
            btnExit = new Button();
            panel1 = new Panel();
            label6 = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvGenres).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // dgvGenres
            // 
            dgvGenres.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvGenres.BackgroundColor = Color.WhiteSmoke;
            dgvGenres.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvGenres.Location = new Point(12, 392);
            dgvGenres.Name = "dgvGenres";
            dgvGenres.RowHeadersWidth = 51;
            dgvGenres.Size = new Size(1238, 269);
            dgvGenres.TabIndex = 0;
            dgvGenres.CellContentClick += dgvGenres_CellContentClick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11F);
            label1.Location = new Point(217, 82);
            label1.Name = "label1";
            label1.Size = new Size(98, 25);
            label1.TabIndex = 1;
            label1.Text = "Genres ID:";
            // 
            // txtGid
            // 
            txtGid.Font = new Font("Segoe UI", 10F);
            txtGid.Location = new Point(342, 77);
            txtGid.Name = "txtGid";
            txtGid.Size = new Size(155, 30);
            txtGid.TabIndex = 2;
            // 
            // txtGname
            // 
            txtGname.Font = new Font("Segoe UI", 10F);
            txtGname.Location = new Point(342, 150);
            txtGname.Name = "txtGname";
            txtGname.Size = new Size(415, 30);
            txtGname.TabIndex = 4;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 11F);
            label2.Location = new Point(185, 155);
            label2.Name = "label2";
            label2.Size = new Size(130, 25);
            label2.TabIndex = 3;
            label2.Text = "Genres Name:";
            // 
            // txtGdes
            // 
            txtGdes.Font = new Font("Segoe UI", 10F);
            txtGdes.Location = new Point(342, 232);
            txtGdes.Name = "txtGdes";
            txtGdes.Size = new Size(414, 120);
            txtGdes.TabIndex = 5;
            txtGdes.Text = "";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11F);
            label3.Location = new Point(139, 231);
            label3.Name = "label3";
            label3.Size = new Size(176, 25);
            label3.TabIndex = 6;
            label3.Text = "Genres Description:";
            // 
            // btnAdd
            // 
            btnAdd.BackColor = Color.CornflowerBlue;
            btnAdd.Font = new Font("Segoe UI", 11F);
            btnAdd.ForeColor = SystemColors.ButtonHighlight;
            btnAdd.Location = new Point(892, 78);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(110, 35);
            btnAdd.TabIndex = 7;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = false;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.BackColor = Color.CornflowerBlue;
            btnUpdate.Font = new Font("Segoe UI", 11F);
            btnUpdate.ForeColor = SystemColors.ButtonHighlight;
            btnUpdate.Location = new Point(892, 155);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(110, 35);
            btnUpdate.TabIndex = 8;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = false;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // btnDelete
            // 
            btnDelete.BackColor = Color.CornflowerBlue;
            btnDelete.Font = new Font("Segoe UI", 11F);
            btnDelete.ForeColor = SystemColors.ButtonHighlight;
            btnDelete.Location = new Point(892, 232);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(110, 35);
            btnDelete.TabIndex = 9;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = false;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnCancel
            // 
            btnCancel.BackColor = Color.CornflowerBlue;
            btnCancel.Font = new Font("Segoe UI", 11F);
            btnCancel.ForeColor = SystemColors.ButtonHighlight;
            btnCancel.Location = new Point(892, 317);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(110, 35);
            btnCancel.TabIndex = 10;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = false;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnExit
            // 
            btnExit.BackColor = Color.Tomato;
            btnExit.Font = new Font("Segoe UI", 11F);
            btnExit.ForeColor = SystemColors.ButtonHighlight;
            btnExit.Location = new Point(1140, 6);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(110, 35);
            btnExit.TabIndex = 11;
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = false;
            btnExit.Click += btnExit_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.CornflowerBlue;
            panel1.Controls.Add(label6);
            panel1.Controls.Add(btnExit);
            panel1.Location = new Point(0, -1);
            panel1.Name = "panel1";
            panel1.Size = new Size(1262, 50);
            panel1.TabIndex = 75;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label6.ForeColor = SystemColors.Control;
            label6.Location = new Point(12, 13);
            label6.Name = "label6";
            label6.Size = new Size(208, 28);
            label6.TabIndex = 74;
            label6.Text = "Genres Management";
            // 
            // Geres
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            ClientSize = new Size(1262, 673);
            Controls.Add(panel1);
            Controls.Add(btnCancel);
            Controls.Add(btnDelete);
            Controls.Add(btnUpdate);
            Controls.Add(btnAdd);
            Controls.Add(label3);
            Controls.Add(txtGdes);
            Controls.Add(txtGname);
            Controls.Add(label2);
            Controls.Add(txtGid);
            Controls.Add(label1);
            Controls.Add(dgvGenres);
            Name = "Geres";
            Text = "Geres";
            Load += Geres_Load;
            ((System.ComponentModel.ISupportInitialize)dgvGenres).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgvGenres;
        private Label label1;
        private TextBox txtGid;
        private TextBox txtGname;
        private Label label2;
        private RichTextBox txtGdes;
        private Label label3;
        private Button btnAdd;
        private Button btnUpdate;
        private Button btnDelete;
        private Button btnCancel;
        private Button btnExit;
        private Panel panel1;
        private Label label6;
    }
}