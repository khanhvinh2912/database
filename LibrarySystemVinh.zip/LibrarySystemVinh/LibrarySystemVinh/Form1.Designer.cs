﻿namespace LibrarySystemVinh
{
    partial class Login
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            panel1 = new Panel();
            Loginbtn = new Button();
            txtPassword = new TextBox();
            label2 = new Label();
            txtUsername = new TextBox();
            label1 = new Label();
            panel2 = new Panel();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BorderStyle = BorderStyle.Fixed3D;
            panel1.Controls.Add(Loginbtn);
            panel1.Controls.Add(txtPassword);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(txtUsername);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(308, 133);
            panel1.Name = "panel1";
            panel1.Size = new Size(626, 388);
            panel1.TabIndex = 0;
            // 
            // Loginbtn
            // 
            Loginbtn.BackColor = Color.CornflowerBlue;
            Loginbtn.FlatStyle = FlatStyle.Popup;
            Loginbtn.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            Loginbtn.ForeColor = SystemColors.ButtonFace;
            Loginbtn.Location = new Point(49, 291);
            Loginbtn.Name = "Loginbtn";
            Loginbtn.Size = new Size(100, 40);
            Loginbtn.TabIndex = 4;
            Loginbtn.Text = "Login";
            Loginbtn.UseVisualStyleBackColor = false;
            Loginbtn.Click += Loginbtn_Click;
            // 
            // txtPassword
            // 
            txtPassword.Location = new Point(49, 221);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(527, 27);
            txtPassword.TabIndex = 3;
            txtPassword.UseSystemPasswordChar = true;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 11F);
            label2.Location = new Point(49, 193);
            label2.Name = "label2";
            label2.Size = new Size(100, 25);
            label2.TabIndex = 2;
            label2.Text = "Password: ";
            // 
            // txtUsername
            // 
            txtUsername.Location = new Point(49, 128);
            txtUsername.Name = "txtUsername";
            txtUsername.Size = new Size(527, 27);
            txtUsername.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11F);
            label1.Location = new Point(49, 100);
            label1.Name = "label1";
            label1.Size = new Size(109, 25);
            label1.TabIndex = 0;
            label1.Text = "User Name:";
            // 
            // panel2
            // 
            panel2.BackColor = Color.CornflowerBlue;
            panel2.BorderStyle = BorderStyle.FixedSingle;
            panel2.Location = new Point(308, 133);
            panel2.Name = "panel2";
            panel2.Size = new Size(626, 50);
            panel2.TabIndex = 5;
            // 
            // Login
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.HighlightText;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1262, 673);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Name = "Login";
            Text = "Login";
            Load += Login_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Button Loginbtn;
        private TextBox txtPassword;
        private Label label2;
        private TextBox txtUsername;
        private Label label1;
        private Panel panel2;
    }
}
