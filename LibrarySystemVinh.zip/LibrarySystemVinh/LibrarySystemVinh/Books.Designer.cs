﻿namespace LibrarySystemVinh
{
    partial class Books
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvBook = new DataGridView();
            txtAid = new TextBox();
            label7 = new Label();
            txtGid = new TextBox();
            label4 = new Label();
            txtBid = new TextBox();
            label1 = new Label();
            label6 = new Label();
            txtTitle = new TextBox();
            label5 = new Label();
            btnExit = new Button();
            btnCancel = new Button();
            btnDelete = new Button();
            btnUpdate = new Button();
            btnAdd = new Button();
            panel1 = new Panel();
            label2 = new Label();
            txtPubDate = new TextBox();
            label3 = new Label();
            label8 = new Label();
            lbAuthorName = new Label();
            lbGenresName = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvBook).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // dgvBook
            // 
            dgvBook.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvBook.BackgroundColor = Color.WhiteSmoke;
            dgvBook.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvBook.Location = new Point(12, 378);
            dgvBook.Name = "dgvBook";
            dgvBook.RowHeadersWidth = 51;
            dgvBook.Size = new Size(1238, 283);
            dgvBook.TabIndex = 3;
            dgvBook.CellContentClick += dgvBook_CellContentClick;
            // 
            // txtAid
            // 
            txtAid.Font = new Font("Segoe UI", 10F);
            txtAid.Location = new Point(995, 101);
            txtAid.Name = "txtAid";
            txtAid.Size = new Size(122, 30);
            txtAid.TabIndex = 67;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 11F);
            label7.Location = new Point(854, 102);
            label7.Name = "label7";
            label7.Size = new Size(97, 25);
            label7.TabIndex = 66;
            label7.Text = "Author ID:";
            // 
            // txtGid
            // 
            txtGid.Font = new Font("Segoe UI", 10F);
            txtGid.Location = new Point(632, 101);
            txtGid.Name = "txtGid";
            txtGid.Size = new Size(122, 30);
            txtGid.TabIndex = 65;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 11F);
            label4.Location = new Point(490, 101);
            label4.Name = "label4";
            label4.Size = new Size(98, 25);
            label4.TabIndex = 64;
            label4.Text = "Genres ID:";
            // 
            // txtBid
            // 
            txtBid.Font = new Font("Segoe UI", 10F);
            txtBid.Location = new Point(279, 100);
            txtBid.Name = "txtBid";
            txtBid.Size = new Size(122, 30);
            txtBid.TabIndex = 63;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11F);
            label1.Location = new Point(154, 101);
            label1.Name = "label1";
            label1.Size = new Size(81, 25);
            label1.TabIndex = 62;
            label1.Text = "Book ID:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 11F);
            label6.Location = new Point(154, 239);
            label6.Name = "label6";
            label6.Size = new Size(153, 25);
            label6.TabIndex = 61;
            label6.Text = "Publication date:";
            // 
            // txtTitle
            // 
            txtTitle.Font = new Font("Segoe UI", 10F);
            txtTitle.Location = new Point(327, 172);
            txtTitle.Name = "txtTitle";
            txtTitle.Size = new Size(246, 30);
            txtTitle.TabIndex = 59;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 11F);
            label5.Location = new Point(154, 172);
            label5.Name = "label5";
            label5.Size = new Size(110, 25);
            label5.TabIndex = 58;
            label5.Text = "Book name:";
            // 
            // btnExit
            // 
            btnExit.BackColor = Color.Tomato;
            btnExit.Font = new Font("Segoe UI", 11F);
            btnExit.ForeColor = SystemColors.ButtonHighlight;
            btnExit.Location = new Point(1140, 13);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(110, 35);
            btnExit.TabIndex = 72;
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = false;
            btnExit.Click += btnExit_Click;
            // 
            // btnCancel
            // 
            btnCancel.BackColor = Color.CornflowerBlue;
            btnCancel.Font = new Font("Segoe UI", 11F);
            btnCancel.ForeColor = SystemColors.ButtonHighlight;
            btnCancel.Location = new Point(942, 309);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(110, 35);
            btnCancel.TabIndex = 71;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = false;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnDelete
            // 
            btnDelete.BackColor = Color.CornflowerBlue;
            btnDelete.Font = new Font("Segoe UI", 11F);
            btnDelete.ForeColor = SystemColors.ButtonHighlight;
            btnDelete.Location = new Point(700, 309);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(110, 35);
            btnDelete.TabIndex = 70;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = false;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.BackColor = Color.CornflowerBlue;
            btnUpdate.Font = new Font("Segoe UI", 11F);
            btnUpdate.ForeColor = SystemColors.ButtonHighlight;
            btnUpdate.Location = new Point(461, 309);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(110, 35);
            btnUpdate.TabIndex = 69;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = false;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // btnAdd
            // 
            btnAdd.BackColor = Color.CornflowerBlue;
            btnAdd.Font = new Font("Segoe UI", 11F);
            btnAdd.ForeColor = SystemColors.ButtonHighlight;
            btnAdd.Location = new Point(231, 309);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(110, 35);
            btnAdd.TabIndex = 68;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = false;
            btnAdd.Click += btnAdd_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.CornflowerBlue;
            panel1.Controls.Add(label2);
            panel1.Controls.Add(btnExit);
            panel1.Location = new Point(0, -4);
            panel1.Name = "panel1";
            panel1.Size = new Size(1262, 56);
            panel1.TabIndex = 73;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label2.ForeColor = SystemColors.Control;
            label2.Location = new Point(12, 13);
            label2.Name = "label2";
            label2.Size = new Size(196, 28);
            label2.TabIndex = 74;
            label2.Text = "Book Management:";
            // 
            // txtPubDate
            // 
            txtPubDate.Font = new Font("Segoe UI", 10F);
            txtPubDate.Location = new Point(327, 240);
            txtPubDate.Name = "txtPubDate";
            txtPubDate.Size = new Size(246, 30);
            txtPubDate.TabIndex = 74;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11F);
            label3.Location = new Point(748, 241);
            label3.Name = "label3";
            label3.Size = new Size(75, 25);
            label3.TabIndex = 76;
            label3.Text = "Genres:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 11F);
            label8.Location = new Point(694, 177);
            label8.Name = "label8";
            label8.Size = new Size(129, 25);
            label8.TabIndex = 78;
            label8.Text = "Author Name:";
            // 
            // lbAuthorName
            // 
            lbAuthorName.AutoSize = true;
            lbAuthorName.Font = new Font("Segoe UI", 11F);
            lbAuthorName.Location = new Point(854, 177);
            lbAuthorName.Name = "lbAuthorName";
            lbAuthorName.Size = new Size(140, 25);
            lbAuthorName.TabIndex = 79;
            lbAuthorName.Text = "________________";
            // 
            // lbGenresName
            // 
            lbGenresName.AutoSize = true;
            lbGenresName.Font = new Font("Segoe UI", 11F);
            lbGenresName.Location = new Point(854, 241);
            lbGenresName.Name = "lbGenresName";
            lbGenresName.Size = new Size(140, 25);
            lbGenresName.TabIndex = 80;
            lbGenresName.Text = "________________";
            // 
            // Books
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1262, 673);
            Controls.Add(lbGenresName);
            Controls.Add(lbAuthorName);
            Controls.Add(label8);
            Controls.Add(label3);
            Controls.Add(txtPubDate);
            Controls.Add(panel1);
            Controls.Add(btnCancel);
            Controls.Add(btnDelete);
            Controls.Add(btnUpdate);
            Controls.Add(btnAdd);
            Controls.Add(txtAid);
            Controls.Add(label7);
            Controls.Add(txtGid);
            Controls.Add(label4);
            Controls.Add(txtBid);
            Controls.Add(label1);
            Controls.Add(label6);
            Controls.Add(txtTitle);
            Controls.Add(label5);
            Controls.Add(dgvBook);
            Name = "Books";
            Text = "Books";
            Load += Books_Load;
            ((System.ComponentModel.ISupportInitialize)dgvBook).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgvBook;
        private TextBox txtAid;
        private Label label7;
        private TextBox txtGid;
        private Label label4;
        private TextBox txtBid;
        private Label label1;
        private Label label6;
        private TextBox txtTitle;
        private Label label5;
        private Button btnExit;
        private Button btnCancel;
        private Button btnDelete;
        private Button btnUpdate;
        private Button btnAdd;
        private Panel panel1;
        private Label label2;
        private TextBox txtPubDate;
        private Label label3;
        private Label label8;
        private Label lbAuthorName;
        private Label lbGenresName;
    }
}