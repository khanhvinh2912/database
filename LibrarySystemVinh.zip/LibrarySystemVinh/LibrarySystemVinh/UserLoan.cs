﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibrarySystemVinh
{
    public partial class UserLoan : Form
    {
        string connectionString;
        SqlConnection con;
        private int loggedInUserID;
        public UserLoan(int userID)
        {
            InitializeComponent();
            this.MaximizeBox = false;
            connectionString = "Server = DESKTOP-FF8V6OC\\HUNGNP; Database = Libary_System; Integrated Security = True";
            con = new SqlConnection(connectionString);
            loggedInUserID = userID;
        }

        private void UserLoan_Load(object sender, EventArgs e)
        {
            DgvShow();
        }
        public void DgvShow()
        {
            string query = "SELECT a.username AS UserName, b.title AS Book, l.loan_date AS LoanDate, l.due_date AS DueDate, s.staff_name AS Staff " +
                  "FROM loans l " +
                  "JOIN Books b ON l.book_id = b.book_id " +
                  "JOIN staff s ON l.staff_id = s.staff_id " +
                  "JOIN Account a ON l.id = a.id " +
                  "WHERE a.id = " + loggedInUserID;

            con.Open();
            DataTable dataTable = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            adapter.Fill(dataTable);
            dgvUloan.DataSource = dataTable;
            con.Close();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            UserPage exit = new UserPage(loggedInUserID);
            this.Hide();
            exit.ShowDialog();
            this.Dispose();
        }
    }
}
