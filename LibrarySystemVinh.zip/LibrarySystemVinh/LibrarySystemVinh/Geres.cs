﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace LibrarySystemVinh
{
    public partial class Geres : Form
    {
        string connectionString;
        SqlConnection con;
        public Geres()
        {
            InitializeComponent();
            this.MaximizeBox = false;
            connectionString = "Server = DESKTOP-FF8V6OC\\HUNGNP; Database = Libary_System; Integrated Security = True";
            con = new SqlConnection(connectionString);
        }

        private void Geres_Load(object sender, EventArgs e)
        {
            DgvShow();
        }
        public void DgvShow()
        {
            string query = "select * from Genres";
            con.Open();
            DataTable dataTable = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            adapter.Fill(dataTable);
            dgvGenres.DataSource = dataTable;
            con.Close();
        }

        private void dgvGenres_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if(e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvGenres.Rows[e.RowIndex];
                txtGid.Text = row.Cells["genres_id"].Value.ToString();
                txtGname.Text = row.Cells["genres_name"].Value.ToString();
                txtGdes.Text = row.Cells["genres_des"].Value.ToString();
                txtGid.Enabled = false;
                btnAdd.Visible = false;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string id = txtGid.Text;
            string name = txtGname.Text;
            string des = txtGdes.Text;
            string insert = "insert into Genres values(" + id + ", '" + name + "', '" + des + "')";
            con.Open();
            SqlCommand cmd = new SqlCommand(insert, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Added succesfully");
            con.Close();
            DgvShow();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string id = txtGid.Text;
            string name = txtGname.Text;
            string des = txtGdes.Text;
            string update = "update Genres set genres_name = '" + name + "', genres_des = '" + des + "' where genres_id = '" + id + "'";
            con.Open();
            SqlCommand cmd = new SqlCommand(update, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Update succesfully");
            con.Close();
            DgvShow();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            var answer = MessageBox.Show("Are you sure you want to delete this row? ", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (answer == DialogResult.Yes)
            {
                string id = txtGid.Text;
                string delete = "delete from Genres where genres_id =" + id;
                con.Open();
                SqlCommand cmd = new SqlCommand(delete, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("delete succesfully");
                con.Close();
                DgvShow();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtGid.Text = "";
            txtGname.Text = "";
            txtGdes.Text = "";
            btnAdd.Visible = true;
            txtGid.Enabled = true;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            AdminPage exit = new AdminPage();
            this.Hide();
            exit.ShowDialog();
            this.Dispose();
        }
    }

}
