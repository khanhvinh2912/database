﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibrarySystemVinh
{
    public partial class AdminPage : Form
    {
        public AdminPage()
        {
            InitializeComponent();      
            this.MaximizeBox = false;
        }

        private void btnBook_Click(object sender, EventArgs e)
        {
            Books books = new Books();
            this.Hide();
            books.ShowDialog();
            this.Dispose();
        }

        private void btnGenres_Click(object sender, EventArgs e)
        {
            Geres geres = new Geres();
            this.Hide();
            geres.ShowDialog(); 
            this.Dispose();
        }

        private void btnAuthor_Click(object sender, EventArgs e)
        {
            Author author = new Author();
            this.Hide();
            author.ShowDialog();
            this.Dispose();
        }

        private void btnStaff_Click(object sender, EventArgs e)
        {
            Staff staff = new Staff();
            this.Hide();
            staff.ShowDialog();
            this.Dispose();
        }

        private void btnLoan_Click(object sender, EventArgs e)
        {
            Loan loan = new Loan();
            this.Hide();
            loan.ShowDialog();
            this.Dispose();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            Login logout = new Login();
            this.Hide();
            logout.ShowDialog();
            this.Dispose();
        }
    }
}
