﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibrarySystemVinh
{
    public partial class Profile : Form
    {
        string connectionString;
        SqlConnection con;
        private int loggedInUserID;
        public Profile(int userID)
        {
            InitializeComponent();
            this.MaximizeBox = false;
            connectionString = "Server = DESKTOP-FF8V6OC\\HUNGNP; Database = Libary_System; Integrated Security = True";
            con = new SqlConnection(connectionString);
            loggedInUserID = userID;
        }

        private void Profile_Load(object sender, EventArgs e)
        {
            DgvShow();
        }
        public void DgvShow()
        {
            string query = "select * from Account where id =" + loggedInUserID;
            con.Open();
            DataTable dataTable = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            adapter.Fill(dataTable);
            dgvProfile.DataSource = dataTable;
            con.Close();
        }

        private void dgvProfile_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvProfile.Rows[e.RowIndex];
                txtUid.Text = row.Cells["id"].Value.ToString();
                txtUname.Text = row.Cells["username"].Value.ToString();
                txtEmail.Text = row.Cells["email"].Value.ToString();
                txtPass.Text = row.Cells["u_password"].Value.ToString();
                txtRole.Text = row.Cells["u_Role"].Value.ToString();
                txtUid.Enabled = false;
                txtRole.Enabled = false;
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string uid = txtUid.Text;
            string name = txtUname.Text;
            string email = txtEmail.Text;
            string pass = txtPass.Text;
            string role = txtRole.Text;
            string update = "update Account set username = '" + name + "', email = '" + email + "', u_password = '" + pass + "' where id = '" + uid + "'";
            con.Open();
            SqlCommand cmd = new SqlCommand(update, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Update succesfully");
            con.Close();
            DgvShow();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtUid.Text = "";
            txtUname.Text = "";
            txtEmail.Text = "";
            txtPass.Text = "";
            txtRole.Text = "";
            txtUid.Enabled = true;
            txtRole.Enabled = true;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            UserPage exit = new UserPage(loggedInUserID);
            this.Hide();
            exit.ShowDialog();
            this.Dispose();
        }
    }
}
