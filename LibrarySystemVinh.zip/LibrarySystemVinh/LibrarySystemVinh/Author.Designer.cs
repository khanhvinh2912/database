﻿namespace LibrarySystemVinh
{
    partial class Author
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvAuthor = new DataGridView();
            txtAuthorName = new TextBox();
            label2 = new Label();
            txtAid = new TextBox();
            label1 = new Label();
            label3 = new Label();
            txtAuthorDob = new TextBox();
            btnCancel = new Button();
            btnDelete = new Button();
            btnUpdate = new Button();
            btnAdd = new Button();
            txtAuthorGender = new TextBox();
            label4 = new Label();
            label5 = new Label();
            txtAuthorCountry = new TextBox();
            panel1 = new Panel();
            label6 = new Label();
            btnExit = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvAuthor).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // dgvAuthor
            // 
            dgvAuthor.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvAuthor.BackgroundColor = Color.WhiteSmoke;
            dgvAuthor.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvAuthor.Location = new Point(12, 392);
            dgvAuthor.Name = "dgvAuthor";
            dgvAuthor.RowHeadersWidth = 51;
            dgvAuthor.Size = new Size(1238, 269);
            dgvAuthor.TabIndex = 1;
            dgvAuthor.CellContentClick += dgvAuthor_CellContentClick;
            // 
            // txtAuthorName
            // 
            txtAuthorName.Font = new Font("Segoe UI", 10F);
            txtAuthorName.Location = new Point(327, 169);
            txtAuthorName.Name = "txtAuthorName";
            txtAuthorName.Size = new Size(259, 30);
            txtAuthorName.TabIndex = 8;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 11F);
            label2.Location = new Point(170, 174);
            label2.Name = "label2";
            label2.Size = new Size(129, 25);
            label2.TabIndex = 7;
            label2.Text = "Author Name:";
            // 
            // txtAid
            // 
            txtAid.Font = new Font("Segoe UI", 10F);
            txtAid.Location = new Point(327, 96);
            txtAid.Name = "txtAid";
            txtAid.Size = new Size(155, 30);
            txtAid.TabIndex = 6;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11F);
            label1.Location = new Point(202, 101);
            label1.Name = "label1";
            label1.Size = new Size(97, 25);
            label1.TabIndex = 5;
            label1.Text = "Author ID:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11F);
            label3.Location = new Point(114, 249);
            label3.Name = "label3";
            label3.Size = new Size(185, 25);
            label3.TabIndex = 9;
            label3.Text = "Author Date of Birth:";
            // 
            // txtAuthorDob
            // 
            txtAuthorDob.Font = new Font("Segoe UI", 10F);
            txtAuthorDob.Location = new Point(327, 244);
            txtAuthorDob.Name = "txtAuthorDob";
            txtAuthorDob.Size = new Size(259, 30);
            txtAuthorDob.TabIndex = 10;
            // 
            // btnCancel
            // 
            btnCancel.BackColor = Color.CornflowerBlue;
            btnCancel.Font = new Font("Segoe UI", 11F);
            btnCancel.ForeColor = SystemColors.ButtonHighlight;
            btnCancel.Location = new Point(936, 318);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(110, 35);
            btnCancel.TabIndex = 14;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = false;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnDelete
            // 
            btnDelete.BackColor = Color.CornflowerBlue;
            btnDelete.Font = new Font("Segoe UI", 11F);
            btnDelete.ForeColor = SystemColors.ButtonHighlight;
            btnDelete.Location = new Point(694, 318);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(110, 35);
            btnDelete.TabIndex = 13;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = false;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.BackColor = Color.CornflowerBlue;
            btnUpdate.Font = new Font("Segoe UI", 11F);
            btnUpdate.ForeColor = SystemColors.ButtonHighlight;
            btnUpdate.Location = new Point(455, 318);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(110, 35);
            btnUpdate.TabIndex = 12;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = false;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // btnAdd
            // 
            btnAdd.BackColor = Color.CornflowerBlue;
            btnAdd.Font = new Font("Segoe UI", 11F);
            btnAdd.ForeColor = SystemColors.ButtonHighlight;
            btnAdd.Location = new Point(225, 318);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(110, 35);
            btnAdd.TabIndex = 11;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = false;
            btnAdd.Click += btnAdd_Click;
            // 
            // txtAuthorGender
            // 
            txtAuthorGender.Font = new Font("Segoe UI", 10F);
            txtAuthorGender.Location = new Point(869, 96);
            txtAuthorGender.Name = "txtAuthorGender";
            txtAuthorGender.Size = new Size(259, 30);
            txtAuthorGender.TabIndex = 16;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 11F);
            label4.Location = new Point(697, 101);
            label4.Name = "label4";
            label4.Size = new Size(141, 25);
            label4.TabIndex = 17;
            label4.Text = "Author Gender:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 11F);
            label5.Location = new Point(692, 174);
            label5.Name = "label5";
            label5.Size = new Size(146, 25);
            label5.TabIndex = 18;
            label5.Text = "Author Country:";
            // 
            // txtAuthorCountry
            // 
            txtAuthorCountry.Font = new Font("Segoe UI", 10F);
            txtAuthorCountry.Location = new Point(869, 174);
            txtAuthorCountry.Name = "txtAuthorCountry";
            txtAuthorCountry.Size = new Size(259, 30);
            txtAuthorCountry.TabIndex = 19;
            // 
            // panel1
            // 
            panel1.BackColor = Color.CornflowerBlue;
            panel1.Controls.Add(label6);
            panel1.Controls.Add(btnExit);
            panel1.Location = new Point(2, -1);
            panel1.Name = "panel1";
            panel1.Size = new Size(1262, 53);
            panel1.TabIndex = 74;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label6.ForeColor = SystemColors.Control;
            label6.Location = new Point(12, 13);
            label6.Name = "label6";
            label6.Size = new Size(209, 28);
            label6.TabIndex = 74;
            label6.Text = "Author Management";
            // 
            // btnExit
            // 
            btnExit.BackColor = Color.Tomato;
            btnExit.Font = new Font("Segoe UI", 11F);
            btnExit.ForeColor = SystemColors.ButtonHighlight;
            btnExit.Location = new Point(1138, 11);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(110, 35);
            btnExit.TabIndex = 72;
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = false;
            btnExit.Click += btnExit_Click;
            // 
            // Author
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1262, 673);
            Controls.Add(panel1);
            Controls.Add(txtAuthorCountry);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(txtAuthorGender);
            Controls.Add(btnCancel);
            Controls.Add(btnDelete);
            Controls.Add(btnUpdate);
            Controls.Add(btnAdd);
            Controls.Add(txtAuthorDob);
            Controls.Add(label3);
            Controls.Add(txtAuthorName);
            Controls.Add(label2);
            Controls.Add(txtAid);
            Controls.Add(label1);
            Controls.Add(dgvAuthor);
            Name = "Author";
            Text = "Author";
            Load += Author_Load;
            ((System.ComponentModel.ISupportInitialize)dgvAuthor).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgvAuthor;
        private TextBox txtAuthorName;
        private Label label2;
        private TextBox txtAid;
        private Label label1;
        private Label label3;
        private TextBox txtAuthorDob;
        private Button btnCancel;
        private Button btnDelete;
        private Button btnUpdate;
        private Button btnAdd;
        private TextBox txtAuthorGender;
        private Label label4;
        private Label label5;
        private TextBox txtAuthorCountry;
        private Panel panel1;
        private Label label6;
        private Button btnExit;
    }
}