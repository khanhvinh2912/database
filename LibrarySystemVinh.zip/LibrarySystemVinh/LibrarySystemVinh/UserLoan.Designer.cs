﻿namespace LibrarySystemVinh
{
    partial class UserLoan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            label7 = new Label();
            btnExit = new Button();
            dgvUloan = new DataGridView();
            label1 = new Label();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvUloan).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.CornflowerBlue;
            panel1.Controls.Add(label7);
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1264, 100);
            panel1.TabIndex = 82;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label7.ForeColor = SystemColors.Control;
            label7.Location = new Point(23, 26);
            label7.Name = "label7";
            label7.Size = new Size(167, 28);
            label7.TabIndex = 74;
            label7.Text = "Borrowed Books";
            // 
            // btnExit
            // 
            btnExit.BackColor = Color.Tomato;
            btnExit.Font = new Font("Segoe UI", 11F);
            btnExit.ForeColor = SystemColors.ButtonHighlight;
            btnExit.Location = new Point(585, 579);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(123, 50);
            btnExit.TabIndex = 75;
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = false;
            btnExit.Click += btnExit_Click;
            // 
            // dgvUloan
            // 
            dgvUloan.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvUloan.BackgroundColor = Color.WhiteSmoke;
            dgvUloan.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvUloan.Location = new Point(23, 227);
            dgvUloan.Name = "dgvUloan";
            dgvUloan.RowHeadersWidth = 51;
            dgvUloan.Size = new Size(1217, 296);
            dgvUloan.TabIndex = 83;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI", 14F);
            label1.ForeColor = Color.Tomato;
            label1.Location = new Point(491, 146);
            label1.Name = "label1";
            label1.Size = new Size(328, 32);
            label1.TabIndex = 84;
            label1.Text = "The books you are borrowing";
            // 
            // UserLoan
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1262, 673);
            Controls.Add(btnExit);
            Controls.Add(label1);
            Controls.Add(dgvUloan);
            Controls.Add(panel1);
            Name = "UserLoan";
            Text = "UserLoan";
            Load += UserLoan_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvUloan).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Button btnExit;
        private Label label7;
        private DataGridView dgvUloan;
        private Label label1;
    }
}