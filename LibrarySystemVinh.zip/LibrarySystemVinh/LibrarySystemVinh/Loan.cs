﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibrarySystemVinh
{
    public partial class Loan : Form
    {
        string connectionString;
        SqlConnection con;
        public Loan()
        {
            InitializeComponent();
            this.MaximizeBox = false;
            connectionString = "Server = DESKTOP-FF8V6OC\\HUNGNP; Database = Libary_System; Integrated Security = True";
            con = new SqlConnection(connectionString);
        }

        private void txtDueDate_TextChanged(object sender, EventArgs e)
        { }

        private void Loan_Load(object sender, EventArgs e)
        {
            DgvShow();
        }
        public void DgvShow()
        {
            string query = "SELECT Loans.loan_id, Loans.book_id, Loans.id, Loans.staff_id, Books.title, Account.username, staff.staff_name, Loans.loan_date, Loans.due_date " +
               "FROM Loans " +
               "LEFT JOIN Account ON Loans.id = Account.id " +
               "LEFT JOIN staff ON Loans.staff_id = staff.staff_id " +
               "LEFT JOIN Books ON Loans.book_id = Books.book_id;";
            con.Open();
            DataTable dataTable = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            adapter.Fill(dataTable);
            dgvLoans.DataSource = dataTable;
            con.Close();
        }

        private void dgvLoans_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvLoans.Rows[e.RowIndex];
                txtUid.Text = row.Cells["id"].Value.ToString();
                txtLid.Text = row.Cells["loan_id"].Value.ToString();
                txtSid.Text = row.Cells["staff_id"].Value.ToString();
                txtBid.Text = row.Cells["book_id"].Value.ToString();
                lbBookName.Text = row.Cells["title"].Value.ToString();
                lbUserName.Text = row.Cells["username"].Value.ToString();
                lbStaffName.Text = row.Cells["staff_name"].Value.ToString();
                txtLoanDate.Text = row.Cells["loan_date"].Value.ToString();
                txtDueDate.Text = row.Cells["due_date"].Value.ToString();
                txtLid.Enabled = false;
                txtBid.Enabled = false;
                txtUid.Enabled = false;
                txtSid.Enabled = false;
                btnAdd.Visible = false;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string bid = txtBid.Text;
            string lid = txtLid.Text;
            string uid = txtUid.Text;
            string sid = txtSid.Text;
            string loandate = txtLoanDate.Text;
            string duedate = txtDueDate.Text;
            string insert = "insert into Loans values(" + lid + ", '" + uid + "', '" + sid + "','" + bid + "', '" + loandate + "', '" + duedate + "')";
            con.Open();
            SqlCommand cmd = new SqlCommand(insert, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Added succesfully");
            con.Close();
            DgvShow();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string bid = txtBid.Text;
            string lid = txtLid.Text;
            string uid = txtUid.Text;
            string sid = txtSid.Text;
            string loandate = txtLoanDate.Text;
            string duedate = txtDueDate.Text;
            string update = "update Loans set loan_date = '" + loandate + "', due_date = '" + duedate + "' where loan_id = '" + lid + "'";
            con.Open();
            SqlCommand cmd = new SqlCommand(update, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Update succesfully");
            con.Close();
            DgvShow();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            var answer = MessageBox.Show("Are you sure you want to delete this row? ", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (answer == DialogResult.Yes)
            {
                string lid = txtLid.Text;
                string delete = "delete from Loans where loan_id =" + lid;
                con.Open();
                SqlCommand cmd = new SqlCommand(delete, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("delete succesfully");
                con.Close();
                DgvShow();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            btnAdd.Visible = true;
            txtLid.Enabled = true;
            txtBid.Enabled = true;
            txtUid.Enabled = true;
            txtSid.Enabled = true;
            txtLid.Text = "";
            txtBid.Text = "";
            txtUid.Text = "";
            txtSid.Text = "";
            txtLoanDate.Text = "";
            txtDueDate.Text = "";
            lbBookName.Text = "_______________";
            lbUserName.Text = "_______________";
            lbStaffName.Text = "_______________";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            AdminPage exit = new AdminPage();
            this.Hide();
            exit.ShowDialog();
            this.Dispose();
        }
    }
}
