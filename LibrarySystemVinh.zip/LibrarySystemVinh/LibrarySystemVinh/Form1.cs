using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibrarySystemVinh
{
    public partial class Login : Form
    {
        string connectionString;
        SqlConnection con;
        public Login()
        {
            InitializeComponent();
            this.MaximizeBox = false;
            connectionString = "Server = DESKTOP-FF8V6OC\\HUNGNP; Database = Libary_System; Integrated Security = True";
            con = new SqlConnection(connectionString);
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void Loginbtn_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;
            string query = "select * from Account where username = '" + username + "' and u_password = '" + password + "'";
            con.Open();
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader rs = cmd.ExecuteReader();
            if (rs.Read())
            {
                int userID = Convert.ToInt32(rs["id"]);
                string role = rs["u_role"].ToString();
                if (role.Equals("admin"))
                {
                    AdminPage f = new AdminPage();
                    this.Hide();
                    f.ShowDialog();
                    this.Dispose();
                }
                else if (role.Equals("user"))
                {
                    UserPage p = new UserPage(userID);
                    this.Hide();
                    p.ShowDialog();
                    this.Dispose();
                }
                else
                {
                    MessageBox.Show("You have not been assigned to any role");
                }
            }
            else
            {
                MessageBox.Show("Wrong usename or password");
            }
            con.Close();
        }
    }
}
