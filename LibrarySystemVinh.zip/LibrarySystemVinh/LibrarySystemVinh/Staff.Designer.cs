﻿namespace LibrarySystemVinh
{
    partial class Staff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvStaff = new DataGridView();
            txtStaffphone = new TextBox();
            label5 = new Label();
            label4 = new Label();
            txtStaffGender = new TextBox();
            txtStaffDob = new TextBox();
            label3 = new Label();
            txtStaffName = new TextBox();
            label2 = new Label();
            txtSid = new TextBox();
            label1 = new Label();
            btnExit = new Button();
            btnCancel = new Button();
            btnDelete = new Button();
            btnUpdate = new Button();
            btnAdd = new Button();
            txtStaffemail = new TextBox();
            label6 = new Label();
            panel1 = new Panel();
            label7 = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvStaff).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // dgvStaff
            // 
            dgvStaff.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvStaff.BackgroundColor = Color.WhiteSmoke;
            dgvStaff.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvStaff.Location = new Point(12, 392);
            dgvStaff.Name = "dgvStaff";
            dgvStaff.RowHeadersWidth = 51;
            dgvStaff.Size = new Size(1238, 269);
            dgvStaff.TabIndex = 2;
            dgvStaff.CellContentClick += dgvStaff_CellContentClick;
            // 
            // txtStaffphone
            // 
            txtStaffphone.Font = new Font("Segoe UI", 10F);
            txtStaffphone.Location = new Point(838, 178);
            txtStaffphone.Name = "txtStaffphone";
            txtStaffphone.Size = new Size(259, 30);
            txtStaffphone.TabIndex = 29;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 11F);
            label5.Location = new Point(661, 179);
            label5.Name = "label5";
            label5.Size = new Size(144, 25);
            label5.TabIndex = 28;
            label5.Text = "Phone Number:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 11F);
            label4.Location = new Point(727, 105);
            label4.Name = "label4";
            label4.Size = new Size(78, 25);
            label4.TabIndex = 27;
            label4.Text = "Gender:";
            // 
            // txtStaffGender
            // 
            txtStaffGender.Font = new Font("Segoe UI", 10F);
            txtStaffGender.Location = new Point(838, 100);
            txtStaffGender.Name = "txtStaffGender";
            txtStaffGender.Size = new Size(259, 30);
            txtStaffGender.TabIndex = 26;
            // 
            // txtStaffDob
            // 
            txtStaffDob.Font = new Font("Segoe UI", 10F);
            txtStaffDob.Location = new Point(296, 248);
            txtStaffDob.Name = "txtStaffDob";
            txtStaffDob.Size = new Size(259, 30);
            txtStaffDob.TabIndex = 25;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11F);
            label3.Location = new Point(125, 253);
            label3.Name = "label3";
            label3.Size = new Size(122, 25);
            label3.TabIndex = 24;
            label3.Text = "Date of Birth:";
            // 
            // txtStaffName
            // 
            txtStaffName.Font = new Font("Segoe UI", 10F);
            txtStaffName.Location = new Point(296, 173);
            txtStaffName.Name = "txtStaffName";
            txtStaffName.Size = new Size(259, 30);
            txtStaffName.TabIndex = 23;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 11F);
            label2.Location = new Point(139, 178);
            label2.Name = "label2";
            label2.Size = new Size(108, 25);
            label2.TabIndex = 22;
            label2.Text = "Staff Name:";
            // 
            // txtSid
            // 
            txtSid.Font = new Font("Segoe UI", 10F);
            txtSid.Location = new Point(296, 100);
            txtSid.Name = "txtSid";
            txtSid.Size = new Size(155, 30);
            txtSid.TabIndex = 21;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11F);
            label1.Location = new Point(171, 105);
            label1.Name = "label1";
            label1.Size = new Size(76, 25);
            label1.TabIndex = 20;
            label1.Text = "Staff ID:";
            // 
            // btnExit
            // 
            btnExit.BackColor = Color.Tomato;
            btnExit.Font = new Font("Segoe UI", 11F);
            btnExit.ForeColor = SystemColors.ButtonHighlight;
            btnExit.Location = new Point(1139, 13);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(110, 35);
            btnExit.TabIndex = 34;
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = false;
            btnExit.Click += btnExit_Click;
            // 
            // btnCancel
            // 
            btnCancel.BackColor = Color.CornflowerBlue;
            btnCancel.Font = new Font("Segoe UI", 11F);
            btnCancel.ForeColor = SystemColors.ButtonHighlight;
            btnCancel.Location = new Point(943, 322);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(110, 35);
            btnCancel.TabIndex = 33;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = false;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnDelete
            // 
            btnDelete.BackColor = Color.CornflowerBlue;
            btnDelete.Font = new Font("Segoe UI", 11F);
            btnDelete.ForeColor = SystemColors.ButtonHighlight;
            btnDelete.Location = new Point(701, 322);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(110, 35);
            btnDelete.TabIndex = 32;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = false;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.BackColor = Color.CornflowerBlue;
            btnUpdate.Font = new Font("Segoe UI", 11F);
            btnUpdate.ForeColor = SystemColors.ButtonHighlight;
            btnUpdate.Location = new Point(462, 322);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(110, 35);
            btnUpdate.TabIndex = 31;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = false;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // btnAdd
            // 
            btnAdd.BackColor = Color.CornflowerBlue;
            btnAdd.Font = new Font("Segoe UI", 11F);
            btnAdd.ForeColor = SystemColors.ButtonHighlight;
            btnAdd.Location = new Point(232, 322);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(110, 35);
            btnAdd.TabIndex = 30;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = false;
            btnAdd.Click += btnAdd_Click;
            // 
            // txtStaffemail
            // 
            txtStaffemail.Font = new Font("Segoe UI", 10F);
            txtStaffemail.Location = new Point(838, 248);
            txtStaffemail.Name = "txtStaffemail";
            txtStaffemail.Size = new Size(259, 30);
            txtStaffemail.TabIndex = 35;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 11F);
            label6.Location = new Point(743, 253);
            label6.Name = "label6";
            label6.Size = new Size(62, 25);
            label6.TabIndex = 36;
            label6.Text = "Email:";
            // 
            // panel1
            // 
            panel1.BackColor = Color.CornflowerBlue;
            panel1.Controls.Add(label7);
            panel1.Controls.Add(btnExit);
            panel1.Location = new Point(1, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1261, 60);
            panel1.TabIndex = 80;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label7.ForeColor = SystemColors.Control;
            label7.Location = new Point(12, 13);
            label7.Name = "label7";
            label7.Size = new Size(189, 28);
            label7.TabIndex = 74;
            label7.Text = "Staff Management";
            // 
            // Staff
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1262, 673);
            Controls.Add(panel1);
            Controls.Add(label6);
            Controls.Add(txtStaffemail);
            Controls.Add(btnCancel);
            Controls.Add(btnDelete);
            Controls.Add(btnUpdate);
            Controls.Add(btnAdd);
            Controls.Add(txtStaffphone);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(txtStaffGender);
            Controls.Add(txtStaffDob);
            Controls.Add(label3);
            Controls.Add(txtStaffName);
            Controls.Add(label2);
            Controls.Add(txtSid);
            Controls.Add(label1);
            Controls.Add(dgvStaff);
            Name = "Staff";
            Text = "Staff";
            Load += Staff_Load;
            ((System.ComponentModel.ISupportInitialize)dgvStaff).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgvStaff;
        private TextBox txtStaffphone;
        private Label label5;
        private Label label4;
        private TextBox txtStaffGender;
        private TextBox txtStaffDob;
        private Label label3;
        private TextBox txtStaffName;
        private Label label2;
        private TextBox txtSid;
        private Label label1;
        private Button btnExit;
        private Button btnCancel;
        private Button btnDelete;
        private Button btnUpdate;
        private Button btnAdd;
        private TextBox txtStaffemail;
        private Label label6;
        private Panel panel1;
        private Label label7;
    }
}