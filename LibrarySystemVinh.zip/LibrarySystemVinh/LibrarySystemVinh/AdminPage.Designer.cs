﻿namespace LibrarySystemVinh
{
    partial class AdminPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminPage));
            pictureBox1 = new PictureBox();
            panel1 = new Panel();
            btnLogout = new Button();
            label1 = new Label();
            btnBook = new Button();
            btnGenres = new Button();
            btnAuthor = new Button();
            btnStaff = new Button();
            btnLoan = new Button();
            panel2 = new Panel();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.BackgroundImage = (Image)resources.GetObject("pictureBox1.BackgroundImage");
            pictureBox1.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox1.Location = new Point(11, 14);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(146, 72);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            panel1.BackColor = Color.WhiteSmoke;
            panel1.Controls.Add(btnLogout);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(pictureBox1);
            panel1.Location = new Point(1, -2);
            panel1.Name = "panel1";
            panel1.Size = new Size(1266, 102);
            panel1.TabIndex = 1;
            // 
            // btnLogout
            // 
            btnLogout.BackColor = Color.Tomato;
            btnLogout.FlatStyle = FlatStyle.Flat;
            btnLogout.Font = new Font("Segoe UI", 11F);
            btnLogout.ForeColor = SystemColors.ButtonHighlight;
            btnLogout.Location = new Point(1132, 31);
            btnLogout.Name = "btnLogout";
            btnLogout.Size = new Size(100, 41);
            btnLogout.TabIndex = 2;
            btnLogout.Text = "Logout";
            btnLogout.UseVisualStyleBackColor = false;
            btnLogout.Click += btnLogout_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 14F);
            label1.Location = new Point(947, 34);
            label1.Name = "label1";
            label1.Size = new Size(147, 32);
            label1.TabIndex = 1;
            label1.Text = "Hello Admin";
            // 
            // btnBook
            // 
            btnBook.BackColor = Color.WhiteSmoke;
            btnBook.FlatStyle = FlatStyle.Popup;
            btnBook.Font = new Font("Segoe UI", 12F);
            btnBook.Location = new Point(119, 52);
            btnBook.Name = "btnBook";
            btnBook.Size = new Size(180, 45);
            btnBook.TabIndex = 0;
            btnBook.Text = "Books";
            btnBook.UseVisualStyleBackColor = false;
            btnBook.Click += btnBook_Click;
            // 
            // btnGenres
            // 
            btnGenres.BackColor = Color.WhiteSmoke;
            btnGenres.FlatStyle = FlatStyle.Popup;
            btnGenres.Font = new Font("Segoe UI", 12F);
            btnGenres.Location = new Point(119, 145);
            btnGenres.Name = "btnGenres";
            btnGenres.Size = new Size(180, 45);
            btnGenres.TabIndex = 1;
            btnGenres.Text = "Genres";
            btnGenres.UseVisualStyleBackColor = false;
            btnGenres.Click += btnGenres_Click;
            // 
            // btnAuthor
            // 
            btnAuthor.BackColor = Color.WhiteSmoke;
            btnAuthor.FlatStyle = FlatStyle.Popup;
            btnAuthor.Font = new Font("Segoe UI", 12F);
            btnAuthor.Location = new Point(119, 234);
            btnAuthor.Name = "btnAuthor";
            btnAuthor.Size = new Size(180, 45);
            btnAuthor.TabIndex = 2;
            btnAuthor.Text = "Author";
            btnAuthor.UseVisualStyleBackColor = false;
            btnAuthor.Click += btnAuthor_Click;
            // 
            // btnStaff
            // 
            btnStaff.BackColor = Color.WhiteSmoke;
            btnStaff.FlatStyle = FlatStyle.Popup;
            btnStaff.Font = new Font("Segoe UI", 12F);
            btnStaff.Location = new Point(119, 321);
            btnStaff.Name = "btnStaff";
            btnStaff.Size = new Size(180, 45);
            btnStaff.TabIndex = 3;
            btnStaff.Text = "Staff";
            btnStaff.UseVisualStyleBackColor = false;
            btnStaff.Click += btnStaff_Click;
            // 
            // btnLoan
            // 
            btnLoan.BackColor = Color.WhiteSmoke;
            btnLoan.FlatStyle = FlatStyle.Popup;
            btnLoan.Font = new Font("Segoe UI", 12F);
            btnLoan.Location = new Point(119, 407);
            btnLoan.Name = "btnLoan";
            btnLoan.Size = new Size(180, 45);
            btnLoan.TabIndex = 4;
            btnLoan.Text = "Loan";
            btnLoan.UseVisualStyleBackColor = false;
            btnLoan.Click += btnLoan_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Transparent;
            panel2.BorderStyle = BorderStyle.FixedSingle;
            panel2.Controls.Add(btnLoan);
            panel2.Controls.Add(btnStaff);
            panel2.Controls.Add(btnAuthor);
            panel2.Controls.Add(btnGenres);
            panel2.Controls.Add(btnBook);
            panel2.Location = new Point(430, 121);
            panel2.Name = "panel2";
            panel2.Size = new Size(420, 514);
            panel2.TabIndex = 2;
            // 
            // AdminPage
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1262, 673);
            Controls.Add(panel2);
            Controls.Add(panel1);
            ForeColor = SystemColors.ActiveCaptionText;
            Name = "AdminPage";
            Text = "AdminPage";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBox1;
        private Panel panel1;
        private Button btnLogout;
        private Label label1;
        private Button btnBook;
        private Button btnGenres;
        private Button btnAuthor;
        private Button btnStaff;
        private Button btnLoan;
        private Panel panel2;
    }
}