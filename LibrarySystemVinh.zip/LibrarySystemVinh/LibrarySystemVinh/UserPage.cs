﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibrarySystemVinh
{
    public partial class UserPage : Form
    {
        private int loggedInUserID;
        public UserPage(int userID)
        {
            InitializeComponent();
            this.MaximizeBox = false;
            loggedInUserID = userID;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Profile profile = new Profile(loggedInUserID);
            this.Hide();
            profile.ShowDialog();
            this.Dispose();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UserLoan userLoan = new UserLoan(loggedInUserID);
            this.Hide();
            userLoan.ShowDialog(); 
            this.Dispose();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            Login logout = new Login();
            this.Hide();
            logout.ShowDialog();
            this.Dispose();
        }
    }
}
