﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace LibrarySystemVinh
{
    public partial class Books : Form
    {
        string connectionString;
        SqlConnection con;
        public Books()
        {
            InitializeComponent();
            this.MaximizeBox = false;
            connectionString = "Server = DESKTOP-FF8V6OC\\HUNGNP; Database = Libary_System; Integrated Security = True";
            con = new SqlConnection(connectionString);
        }

        private void Books_Load(object sender, EventArgs e)
        {
            DgvShow();
        }
        public void DgvShow()
        {
            string query = "SELECT Books.book_id, Books.author_id, Authors.author_name, Books.genres_id, Genres.genres_name, Books.title, Books.public_date " +
               "FROM Books " +
               "LEFT JOIN Authors ON Books.author_id = Authors.author_id " +
               "LEFT JOIN Genres ON Books.genres_id = Genres.genres_id;";
            con.Open();
            DataTable dataTable = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            adapter.Fill(dataTable);
            dgvBook.DataSource = dataTable;
            con.Close();
        }

        private void dgvBook_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvBook.Rows[e.RowIndex];
                txtAid.Text = row.Cells["author_id"].Value.ToString();
                txtBid.Text = row.Cells["book_id"].Value.ToString();
                txtGid.Text = row.Cells["genres_id"].Value.ToString();
                lbAuthorName.Text = row.Cells["author_name"].Value.ToString();
                lbGenresName.Text = row.Cells["genres_name"].Value.ToString();
                txtPubDate.Text = row.Cells["public_date"].Value.ToString();
                txtTitle.Text = row.Cells["title"].Value.ToString();
                txtAid.Enabled = false;
                txtBid.Enabled = false;
                txtGid.Enabled = false;
                btnAdd.Visible = false;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string bid = txtBid.Text;
            string aid = txtAid.Text;
            string gid = txtGid.Text;
            string title = txtTitle.Text;
            string pubdate = txtPubDate.Text;
            string insert = "insert into Books values(" + bid + ", '" + title + "', '" + aid + "','" + gid + "', '" + pubdate + "')";
            con.Open();
            SqlCommand cmd = new SqlCommand(insert, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Added succesfully");
            con.Close();
            DgvShow();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string bid = txtBid.Text;
            string aid = txtAid.Text;
            string gid = txtGid.Text;
            string title = txtTitle.Text;
            string pubdate = txtPubDate.Text;
            string update = "update Books set title = '" + title + "', public_date = '" + pubdate + "' where book_id = '" + bid + "'";
            con.Open();
            SqlCommand cmd = new SqlCommand(update, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Update succesfully");
            con.Close();
            DgvShow();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            var answer = MessageBox.Show("Are you sure you want to delete this row? ", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (answer == DialogResult.Yes)
            {
                string bid = txtBid.Text;
                string delete = "delete from Books where book_id =" + bid;
                con.Open();
                SqlCommand cmd = new SqlCommand(delete, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("delete succesfully");
                con.Close();
                DgvShow();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            btnAdd.Visible = true;
            txtBid.Enabled = true;
            txtAid.Enabled = true;
            txtGid.Enabled = true;     
            txtBid.Text = "";
            txtAid.Text = "";
            txtGid.Text = "";
            txtTitle.Text = "";
            lbAuthorName.Text = "_______________";
            lbGenresName.Text = "_______________";
            txtPubDate.Text = "";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            AdminPage exit = new AdminPage();
            this.Hide();
            exit.ShowDialog();
            this.Dispose();
        }
    }
}
