﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibrarySystemVinh
{
    public partial class Staff : Form
    {
        string connectionString;
        SqlConnection con;
        public Staff()
        {
            InitializeComponent();
            this.MaximizeBox = false;
            connectionString = "Server = DESKTOP-FF8V6OC\\HUNGNP; Database = Libary_System; Integrated Security = True";
            con = new SqlConnection(connectionString);
        }

        private void Staff_Load(object sender, EventArgs e)
        {
            DgvShow();
        }
        public void DgvShow()
        {
            string query = "select * from Staff";
            con.Open();
            DataTable dataTable = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            adapter.Fill(dataTable);
            dgvStaff.DataSource = dataTable;
            con.Close();
        }

        private void dgvStaff_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvStaff.Rows[e.RowIndex];
                txtSid.Text = row.Cells["staff_id"].Value.ToString();
                txtStaffName.Text = row.Cells["staff_name"].Value.ToString();
                txtStaffDob.Text = row.Cells["staff_dob"].Value.ToString();
                txtStaffGender.Text = row.Cells["staff_gender"].Value.ToString();
                txtStaffemail.Text = row.Cells["email"].Value.ToString();
                txtStaffphone.Text = row.Cells["phone"].Value.ToString();
                txtSid.Enabled = false;
                btnAdd.Visible = false;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string sid = txtSid.Text;
            string S_name = txtStaffName.Text;
            string S_dob = txtStaffDob.Text;
            string S_gender = txtStaffGender.Text;
            string S_email = txtStaffemail.Text;
            string S_phone = txtStaffphone.Text;
            string insert = "insert into staff values(" + sid + ", '" + S_name + "', '" + S_dob + "','" + S_gender + "', '" + S_email + "', '" + S_phone + "')";
            con.Open();
            SqlCommand cmd = new SqlCommand(insert, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Added succesfully");
            con.Close();
            DgvShow();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string sid = txtSid.Text;
            string S_name = txtStaffName.Text;
            string S_dob = txtStaffDob.Text;
            string S_gender = txtStaffGender.Text;
            string S_email = txtStaffemail.Text;
            string S_phone = txtStaffphone.Text;
            string update = "update staff set staff_name = '" + S_name + "', staff_dob = '" + S_dob + "', staff_gender = '" + S_gender + "', email = '" + S_email + "', phone = '" + S_phone + "' where staff_id = '" + sid + "'";
            con.Open();
            SqlCommand cmd = new SqlCommand(update, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Update succesfully");
            con.Close();
            DgvShow();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            var answer = MessageBox.Show("Are you sure you want to delete this row? ", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (answer == DialogResult.Yes)
            {
                string sid = txtSid.Text;
                string delete = "delete from staff where staff_id =" + sid;
                con.Open();
                SqlCommand cmd = new SqlCommand(delete, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("delete succesfully");
                con.Close();
                DgvShow();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            btnAdd.Visible = true;
            txtSid.Enabled = true;
            txtSid.Text = "";
            txtStaffName.Text = "";
            txtStaffDob.Text = "";
            txtStaffGender.Text = "";
            txtStaffemail.Text = "";
            txtStaffphone.Text = "";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            AdminPage exit = new AdminPage();
            this.Hide();
            exit.ShowDialog();
            this.Dispose();
        }
    }
}
