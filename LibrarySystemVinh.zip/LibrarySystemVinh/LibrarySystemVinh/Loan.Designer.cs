﻿namespace LibrarySystemVinh
{
    partial class Loan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtSid = new TextBox();
            label7 = new Label();
            txtUid = new TextBox();
            label4 = new Label();
            txtBid = new TextBox();
            label1 = new Label();
            label6 = new Label();
            txtDueDate = new TextBox();
            txtLoanDate = new TextBox();
            label5 = new Label();
            dgvLoans = new DataGridView();
            panel1 = new Panel();
            btnExit = new Button();
            label2 = new Label();
            btnCancel = new Button();
            btnDelete = new Button();
            btnUpdate = new Button();
            btnAdd = new Button();
            lbBookName = new Label();
            label8 = new Label();
            lbUserName = new Label();
            label9 = new Label();
            lbStaffName = new Label();
            label11 = new Label();
            txtLid = new TextBox();
            label3 = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvLoans).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // txtSid
            // 
            txtSid.Font = new Font("Segoe UI", 10F);
            txtSid.Location = new Point(1029, 95);
            txtSid.Name = "txtSid";
            txtSid.Size = new Size(110, 30);
            txtSid.TabIndex = 77;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 11F);
            label7.Location = new Point(947, 100);
            label7.Name = "label7";
            label7.Size = new Size(76, 25);
            label7.TabIndex = 76;
            label7.Text = "Staff ID:";
            // 
            // txtUid
            // 
            txtUid.Font = new Font("Segoe UI", 10F);
            txtUid.Location = new Point(759, 97);
            txtUid.Name = "txtUid";
            txtUid.Size = new Size(110, 30);
            txtUid.TabIndex = 75;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 11F);
            label4.Location = new Point(676, 98);
            label4.Name = "label4";
            label4.Size = new Size(77, 25);
            label4.TabIndex = 74;
            label4.Text = "User ID:";
            // 
            // txtBid
            // 
            txtBid.Font = new Font("Segoe UI", 10F);
            txtBid.Location = new Point(493, 95);
            txtBid.Name = "txtBid";
            txtBid.Size = new Size(110, 30);
            txtBid.TabIndex = 73;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11F);
            label1.Location = new Point(406, 98);
            label1.Name = "label1";
            label1.Size = new Size(81, 25);
            label1.TabIndex = 72;
            label1.Text = "Book ID:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 11F);
            label6.Location = new Point(671, 250);
            label6.Name = "label6";
            label6.Size = new Size(94, 25);
            label6.TabIndex = 71;
            label6.Text = "Due Date:";
            // 
            // txtDueDate
            // 
            txtDueDate.Font = new Font("Segoe UI", 10F);
            txtDueDate.Location = new Point(789, 246);
            txtDueDate.Name = "txtDueDate";
            txtDueDate.Size = new Size(255, 30);
            txtDueDate.TabIndex = 70;
            txtDueDate.TextChanged += txtDueDate_TextChanged;
            // 
            // txtLoanDate
            // 
            txtLoanDate.Font = new Font("Segoe UI", 10F);
            txtLoanDate.Location = new Point(353, 245);
            txtLoanDate.Name = "txtLoanDate";
            txtLoanDate.Size = new Size(252, 30);
            txtLoanDate.TabIndex = 69;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 11F);
            label5.Location = new Point(219, 246);
            label5.Name = "label5";
            label5.Size = new Size(101, 25);
            label5.TabIndex = 68;
            label5.Text = "Loan Date:";
            // 
            // dgvLoans
            // 
            dgvLoans.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvLoans.BackgroundColor = Color.WhiteSmoke;
            dgvLoans.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvLoans.Location = new Point(12, 378);
            dgvLoans.Name = "dgvLoans";
            dgvLoans.RowHeadersWidth = 51;
            dgvLoans.Size = new Size(1238, 283);
            dgvLoans.TabIndex = 78;
            dgvLoans.CellContentClick += dgvLoans_CellContentClick;
            // 
            // panel1
            // 
            panel1.BackColor = Color.CornflowerBlue;
            panel1.Controls.Add(btnExit);
            panel1.Controls.Add(label2);
            panel1.Location = new Point(-2, -2);
            panel1.Name = "panel1";
            panel1.Size = new Size(1267, 55);
            panel1.TabIndex = 79;
            // 
            // btnExit
            // 
            btnExit.BackColor = Color.Tomato;
            btnExit.Font = new Font("Segoe UI", 11F);
            btnExit.ForeColor = SystemColors.ButtonHighlight;
            btnExit.Location = new Point(1142, 11);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(110, 35);
            btnExit.TabIndex = 80;
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = false;
            btnExit.Click += btnExit_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label2.ForeColor = SystemColors.Control;
            label2.Location = new Point(12, 13);
            label2.Name = "label2";
            label2.Size = new Size(287, 28);
            label2.TabIndex = 74;
            label2.Text = "Loans and Due Management:";
            // 
            // btnCancel
            // 
            btnCancel.BackColor = Color.CornflowerBlue;
            btnCancel.Font = new Font("Segoe UI", 11F);
            btnCancel.ForeColor = SystemColors.ButtonHighlight;
            btnCancel.Location = new Point(934, 317);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(110, 35);
            btnCancel.TabIndex = 84;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = false;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnDelete
            // 
            btnDelete.BackColor = Color.CornflowerBlue;
            btnDelete.Font = new Font("Segoe UI", 11F);
            btnDelete.ForeColor = SystemColors.ButtonHighlight;
            btnDelete.Location = new Point(692, 317);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(110, 35);
            btnDelete.TabIndex = 83;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = false;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.BackColor = Color.CornflowerBlue;
            btnUpdate.Font = new Font("Segoe UI", 11F);
            btnUpdate.ForeColor = SystemColors.ButtonHighlight;
            btnUpdate.Location = new Point(453, 317);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(110, 35);
            btnUpdate.TabIndex = 82;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = false;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // btnAdd
            // 
            btnAdd.BackColor = Color.CornflowerBlue;
            btnAdd.Font = new Font("Segoe UI", 11F);
            btnAdd.ForeColor = SystemColors.ButtonHighlight;
            btnAdd.Location = new Point(223, 317);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(110, 35);
            btnAdd.TabIndex = 81;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = false;
            btnAdd.Click += btnAdd_Click;
            // 
            // lbBookName
            // 
            lbBookName.AutoSize = true;
            lbBookName.Font = new Font("Segoe UI", 11F);
            lbBookName.Location = new Point(227, 172);
            lbBookName.Name = "lbBookName";
            lbBookName.Size = new Size(140, 25);
            lbBookName.TabIndex = 86;
            lbBookName.Text = "________________";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 11F);
            label8.Location = new Point(108, 172);
            label8.Name = "label8";
            label8.Size = new Size(113, 25);
            label8.TabIndex = 85;
            label8.Text = "Book Name:";
            // 
            // lbUserName
            // 
            lbUserName.AutoSize = true;
            lbUserName.Font = new Font("Segoe UI", 11F);
            lbUserName.Location = new Point(729, 172);
            lbUserName.Name = "lbUserName";
            lbUserName.Size = new Size(140, 25);
            lbUserName.TabIndex = 88;
            lbUserName.Text = "________________";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 11F);
            label9.Location = new Point(614, 172);
            label9.Name = "label9";
            label9.Size = new Size(109, 25);
            label9.TabIndex = 87;
            label9.Text = "User Name:";
            // 
            // lbStaffName
            // 
            lbStaffName.AutoSize = true;
            lbStaffName.Font = new Font("Segoe UI", 11F);
            lbStaffName.Location = new Point(1029, 172);
            lbStaffName.Name = "lbStaffName";
            lbStaffName.Size = new Size(140, 25);
            lbStaffName.TabIndex = 90;
            lbStaffName.Text = "________________";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 11F);
            label11.Location = new Point(915, 172);
            label11.Name = "label11";
            label11.Size = new Size(108, 25);
            label11.TabIndex = 89;
            label11.Text = "Staff Name:";
            // 
            // txtLid
            // 
            txtLid.Font = new Font("Segoe UI", 10F);
            txtLid.Location = new Point(215, 97);
            txtLid.Name = "txtLid";
            txtLid.Size = new Size(110, 30);
            txtLid.TabIndex = 92;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11F);
            label3.Location = new Point(129, 98);
            label3.Name = "label3";
            label3.Size = new Size(80, 25);
            label3.TabIndex = 91;
            label3.Text = "Loan ID:";
            // 
            // Loan
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1262, 673);
            Controls.Add(txtLid);
            Controls.Add(label3);
            Controls.Add(lbStaffName);
            Controls.Add(label11);
            Controls.Add(lbUserName);
            Controls.Add(label9);
            Controls.Add(lbBookName);
            Controls.Add(label8);
            Controls.Add(btnCancel);
            Controls.Add(panel1);
            Controls.Add(btnDelete);
            Controls.Add(btnUpdate);
            Controls.Add(dgvLoans);
            Controls.Add(btnAdd);
            Controls.Add(txtSid);
            Controls.Add(label7);
            Controls.Add(txtUid);
            Controls.Add(label4);
            Controls.Add(txtBid);
            Controls.Add(label1);
            Controls.Add(label6);
            Controls.Add(txtDueDate);
            Controls.Add(txtLoanDate);
            Controls.Add(label5);
            Name = "Loan";
            Text = "Loan";
            Load += Loan_Load;
            ((System.ComponentModel.ISupportInitialize)dgvLoans).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtSid;
        private Label label7;
        private TextBox txtUid;
        private Label label4;
        private TextBox txtBid;
        private Label label1;
        private Label label6;
        private TextBox txtDueDate;
        private TextBox txtLoanDate;
        private Label label5;
        private DataGridView dgvLoans;
        private Panel panel1;
        private Label label2;
        private Button btnExit;
        private Button btnCancel;
        private Button btnDelete;
        private Button btnUpdate;
        private Button btnAdd;
        private Label lbBookName;
        private Label label8;
        private Label lbUserName;
        private Label label9;
        private Label lbStaffName;
        private Label label11;
        private TextBox txtLid;
        private Label label3;
    }
}